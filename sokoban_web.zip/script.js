const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const size = 40;
let score = 0;
const map = [
  [1,1,1,1,1,1,1,1,1,1],
  [1,0,0,0,0,0,0,0,2,1],
  [1,0,3,0,0,0,0,0,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,1,1,1,1,1,1,1,1,1]
];
let player = {x: 2, y: 2};
function draw() {
  for (let y = 0; y < map.length; y++) {
    for (let x = 0; x < map[y].length; x++) {
      if (map[y][x] === 1) ctx.fillStyle = '#444';
      else if (map[y][x] === 2) ctx.fillStyle = '#f00';
      else if (map[y][x] === 3) ctx.fillStyle = '#964B00';
      else ctx.fillStyle = '#fff';
      ctx.fillRect(x * size, y * size, size, size);
      ctx.strokeRect(x * size, y * size, size, size);
    }
  }
  ctx.fillStyle = '#00f';
  ctx.fillRect(player.x * size + 8, player.y * size + 8, 24, 24);
}
function move(dx, dy) {
  const nx = player.x + dx;
  const ny = player.y + dy;
  if (map[ny][nx] === 1) return;
  if (map[ny][nx] === 3) {
    const bx = nx + dx;
    const by = ny + dy;
    if (map[by][bx] === 0 || map[by][bx] === 2) {
      map[by][bx] = 3;
      map[ny][nx] = 0;
      if (map[by][bx] === 2) score++;
    } else return;
  }
  player.x = nx;
  player.y = ny;
  document.getElementById('score').innerText = score;
  draw();
}
document.addEventListener('keydown', e => {
  if (e.key === 'ArrowUp') move(0, -1);
  else if (e.key === 'ArrowDown') move(0, 1);
  else if (e.key === 'ArrowLeft') move(-1, 0);
  else if (e.key === 'ArrowRight') move(1, 0);
});
draw();